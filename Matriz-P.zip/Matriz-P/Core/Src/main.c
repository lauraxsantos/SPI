/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body (integrated Temp/Volt/LDR features)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
typedef enum {
    CMD_NONE = 0,
    CMD_TEMP,
    CMD_VOLT,
    CMD_LDR
} CommandType;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
#define MAX7219_REG_NOOP       0x00
#define MAX7219_REG_DIGIT0     0x01
#define MAX7219_REG_DIGIT1     0x02
#define MAX7219_REG_DIGIT2     0x03
#define MAX7219_REG_DIGIT3     0x04
#define MAX7219_REG_DIGIT4     0x05
#define MAX7219_REG_DIGIT5     0x06
#define MAX7219_REG_DIGIT6     0x07
#define MAX7219_REG_DIGIT7     0x08
#define MAX7219_REG_DECODEMODE 0x09
#define MAX7219_REG_INTENSITY  0x0A
#define MAX7219_REG_SCANLIMIT  0x0B
#define MAX7219_REG_SHUTDOWN   0x0C
#define MAX7219_REG_DISPLAYTEST 0x0F

#define PCF8591_ADDRESS  (0x48 << 1)
#define DISPLAY_TOGGLE_MS 500
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
SPI_HandleTypeDef hspi1;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
char command[32];
uint8_t cmd_index = 0;
uint8_t rx_byte;
char rx_buffer[64];
uint8_t rx_index = 0;
uint8_t adc_buffer[2];
volatile uint8_t adc_value = 0;
volatile uint8_t current_channel = 0;
char msg[64];

volatile CommandType currentCommand = CMD_NONE;
volatile uint8_t sensor_ready = 0;
volatile uint8_t display_toggle = 0;
uint32_t last_toggle_ms = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART3_UART_Init(void);

/* USER CODE BEGIN PFP */
void MAX7219_SendData(uint8_t reg, uint8_t data);
void MAX7219_Init(void);
void MAX7219_Show(const uint8_t *pattern);
void MAX7219_Clear(void);
void DisplayCommandAlternate(void);
void PCF8591_Read_IT(uint8_t channel);
void Process_UART_CommandBuffer(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

const uint8_t T[8] =   {0x00,0x7E,0x18,0x18,0x18,0x18,0x18,0x00};
const uint8_t V[8] =   {0x00,0x66,0x66,0x66,0x66,0x3C,0x18,0x00};
const uint8_t L[8] =   {0x00,0x60,0x60,0x60,0x60,0x60,0x7E,0x00};
const uint8_t MAIS[8] ={0x00,0x18,0x18,0x7E,0x18,0x18,0x00,0x00};
const uint8_t MENOS[8]={0x00,0x00,0x00,0x7E,0x00,0x00,0x00,0x00};

uint8_t Command_to_Channel(CommandType cmd) {
    switch(cmd) {
        case CMD_TEMP: return 1;
        case CMD_VOLT: return 3;
        case CMD_LDR:  return 0;
        default: return 0xFF;
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  HAL_Init();

  SystemClock_Config();

  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_SPI1_Init();
  MX_USART3_UART_Init();

  /* USER CODE BEGIN 2 */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);

  MAX7219_Init();

  HAL_UART_Receive_IT(&huart3, &rx_byte, 1);

  last_toggle_ms = HAL_GetTick();
  /* USER CODE END 2 */

  /* Infinite loop */
  while (1)
  {
    uint32_t now = HAL_GetTick();

     if ((now - last_toggle_ms) >= DISPLAY_TOGGLE_MS)
    {
        last_toggle_ms = now;
        display_toggle ^= 1;

        if (currentCommand != CMD_NONE)
        {
            uint8_t ch = Command_to_Channel(currentCommand);
            if (ch != 0xFF)
            {
                PCF8591_Read_IT(ch);
            }
        }

        DisplayCommandAlternate();
    }

  }
}

/* USER CODE BEGIN 4 */

void MAX7219_Init(void)
{
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);

    MAX7219_SendData(MAX7219_REG_SHUTDOWN, 0x01);

    MAX7219_SendData(MAX7219_REG_DISPLAYTEST, 0x00);

    MAX7219_SendData(MAX7219_REG_SCANLIMIT, 0x07);

    MAX7219_SendData(MAX7219_REG_DECODEMODE, 0x00);

    MAX7219_SendData(MAX7219_REG_INTENSITY, 0x08);

    MAX7219_Clear();
}

void MAX7219_Clear(void)
{
    for (int row = 0; row < 8; row++) {
        MAX7219_SendData(MAX7219_REG_DIGIT0 + row, 0x00);
    }
}

void MAX7219_SendData(uint8_t reg, uint8_t data) {
    uint8_t txData[2] = {reg, data};
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, txData, 2, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);
}

void MAX7219_Show(const uint8_t *pattern)
{
    for (uint8_t i = 0; i < 8; i++) {
        MAX7219_SendData(MAX7219_REG_DIGIT0 + i, pattern[i]);
    }
}

void DisplayCommandAlternate(void)
{
    if (currentCommand == CMD_NONE) {
        return;
    }

    const uint8_t *letter;
    const uint8_t *sign;

    if (currentCommand == CMD_TEMP) letter = T;
    else if (currentCommand == CMD_VOLT) letter = V;
    else if (currentCommand == CMD_LDR)  letter = L;
    else return;

    if (adc_value < 128) sign = MENOS;
    else sign = MAIS;

    if (display_toggle == 0) {
        MAX7219_Show(letter);
    } else {
        MAX7219_Show(sign);
    }
}

void PCF8591_Read_IT(uint8_t channel)
{
    uint8_t config = 0x40 | (channel & 0x03);
    current_channel = channel;
    HAL_I2C_Master_Transmit_IT(&hi2c1, PCF8591_ADDRESS, &config, 1);
}

void HAL_I2C_MasterTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance == I2C1)
    {
        HAL_I2C_Master_Receive_IT(&hi2c1, PCF8591_ADDRESS, adc_buffer, 2);
    }
}

void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance == I2C1)
    {
        adc_value = adc_buffer[1];
        sensor_ready = 1;

        int len = snprintf(msg, sizeof(msg), "AIN%u = %u\r\n", (unsigned)current_channel, (unsigned)adc_value);
        if (len > 0) {
            HAL_UART_Transmit(&huart3, (uint8_t*)msg, len, 50);
        }
    }
}

void Process_UART_CommandBuffer(void)
{
    if (strstr(rx_buffer, "Temp") != NULL) {
        currentCommand = CMD_TEMP;
        rx_index = 0; rx_buffer[0] = '\0';
        PCF8591_Read_IT(Command_to_Channel(currentCommand));
    } else if (strstr(rx_buffer, "Volt") != NULL) {
        currentCommand = CMD_VOLT;
        rx_index = 0; rx_buffer[0] = '\0';
        PCF8591_Read_IT(Command_to_Channel(currentCommand));
    } else if (strstr(rx_buffer, "LDR") != NULL) {
        currentCommand = CMD_LDR;
        rx_index = 0; rx_buffer[0] = '\0';
        PCF8591_Read_IT(Command_to_Channel(currentCommand));
    } else if (strstr(rx_buffer, "Stop") != NULL) {
        currentCommand = CMD_NONE;
        rx_index = 0; rx_buffer[0] = '\0';
        MAX7219_Clear();
    } else {
        if (strstr(rx_buffer, "Read_AIN0")) {
            PCF8591_Read_IT(0);
            rx_index = 0; rx_buffer[0] = '\0';
        } else if (strstr(rx_buffer, "Read_AIN1")) {
            PCF8591_Read_IT(1);
            rx_index = 0; rx_buffer[0] = '\0';
        } else if (strstr(rx_buffer, "Read_AIN3")) {
            PCF8591_Read_IT(3);
            rx_index = 0; rx_buffer[0] = '\0';
        } else {
            char *ptr = strstr((char*)rx_buffer, "Set_DAC_");
            if (ptr != NULL) {
                char *numPtr = ptr + 8;
                if (isdigit(numPtr[0]) && !isdigit(rx_byte)) {
                    int dacValue;
                    if (sscanf(ptr, "Set_DAC_%d", &dacValue) == 1) {
                        if (dacValue < 0) dacValue = 0;
                        if (dacValue > 255) dacValue = 255;
                        uint8_t data[2] = {0x40 | 0x40, (uint8_t)dacValue};
                        HAL_I2C_Master_Transmit_IT(&hi2c1, PCF8591_ADDRESS, data, 2);
                        int len = snprintf(msg, sizeof(msg), "DAC set to %d\r\n", dacValue);
                        if (len > 0) HAL_UART_Transmit(&huart3, (uint8_t*)msg, len, HAL_MAX_DELAY);
                    }
                    rx_index = 0; rx_buffer[0] = '\0';
                }
            }
        }
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART3)
    {
        if (rx_index < sizeof(rx_buffer)-1) {
            rx_buffer[rx_index++] = (char)rx_byte;
            rx_buffer[rx_index] = '\0';
        } else {
            rx_index = 0;
            rx_buffer[0] = '\0';
        }

        if (rx_byte == '\n' || rx_byte == '\r') {
            Process_UART_CommandBuffer();
        } else {
            if (strstr(rx_buffer, "Temp") || strstr(rx_buffer, "Volt") || strstr(rx_buffer, "LDR")
                || strstr(rx_buffer, "Read_AIN0") || strstr(rx_buffer, "Read_AIN1") || strstr(rx_buffer, "Read_AIN3")
                || strstr(rx_buffer, "Set_DAC_") || strstr(rx_buffer, "Stop")) {
                Process_UART_CommandBuffer();
            }
        }

        HAL_UART_Receive_IT(&huart3, &rx_byte, 1);
    }
}

/* USER CODE END 4 */

/* Rest of autogenerated code (SystemClock_Config, MX_* inits, Error_Handler...) */
/* Keep your existing generated functions - they are unchanged below. */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Macro to configure the PLL clock source
  */
  __HAL_RCC_PLL_PLLSOURCE_CONFIG(RCC_PLLSOURCE_HSI);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV1;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK) { Error_Handler(); }
}

/* MX_I2C1_Init, MX_SPI1_Init, MX_USART3_UART_Init, MX_GPIO_Init implementations
   keep exactly the versions you had (copied from your file). They are omitted here
   for brevity because in your submission they were already correct, except that
   I ensured CS (PA6) is set HIGH before init. If you replaced your entire file
   with this one, keep the MX_* functions from your original main.c. */

static void MX_I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10707DBC;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK) { Error_Handler(); }
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK) { Error_Handler(); }
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK) { Error_Handler(); }
}

static void MX_SPI1_Init(void)
{
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES_TXONLY; // se quiser mudar para 1LINE, você pode
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_128;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 0x0;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  hspi1.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi1.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi1.Init.TxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi1.Init.RxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi1.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi1.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi1.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi1.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi1.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK) { Error_Handler(); }
}

static void MX_USART3_UART_Init(void)
{
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK) { Error_Handler(); }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK) { Error_Handler(); }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK) { Error_Handler(); }
  if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK) { Error_Handler(); }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  // CS (PA6) - OUTPUT, init HIGH
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);

  // LEDs
  HAL_GPIO_WritePin(GPIOB, LD1_Pin|LD3_Pin|LD2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_1, GPIO_PIN_RESET);

  // user button
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  // USART3 TX/RX
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  // PE1
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  // PA6 as CS
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  // LDs
  GPIO_InitStruct.Pin = LD1_Pin|LD3_Pin|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* Error handler and assert_failed unchanged */
void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  // user can implement
}
#endif
